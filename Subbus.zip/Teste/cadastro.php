<p style="color:black"><?php
  
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'lib/vendor/autoload.php';

  session_start();
  ob_start();
  $btnCadUsuario = filter_input(INPUT_POST,'btnCadUsuario',FILTER_SANITIZE_STRING);
  if($btnCadUsuario){
    include_once('cadastro_conexao.php');
    $dados_rc = filter_input_array(INPUT_POST,FILTER_DEFAULT);
  
    $erro = false;
  
    $dados_st = array_map('strip_tags',$dados_rc);
    $dados = array_map('trim',$dados_st);
    
    if(in_array('',$dados)){
      $erro = true;    }
    else if((strlen($dados['senha']))<8){
      $erro = true;    }
    else if((stristr($dados['nome'],"'") AND stristr($dados['nome'],"!")) AND (stristr($dados['nome'],"@")) AND (stristr($dados['nome'],"#")) AND (stristr($dados['nome'],"$"))
     AND (stristr($dados['nome'],"%")) AND (stristr($dados['nome'],"¨")) AND (stristr($dados['nome'],"&")) AND (stristr($dados['nome'],"&")) AND (stristr($dados['nome'],"*"))
      AND (stristr($dados['nome'],"(")) AND (stristr($dados['nome'],")")) AND (stristr($dados['nome'],"_")) AND (stristr($dados['nome'],"=")) AND (stristr($dados['nome'],"+"))
       AND (stristr($dados['nome'],"§")) AND (stristr($dados['nome'],"[")) AND (stristr($dados['nome'],"]")) AND (stristr($dados['nome'],"{")) AND (stristr($dados['nome'],"}"))
        AND (stristr($dados['nome'],"ª")) AND (stristr($dados['nome'],"º")) AND (stristr($dados['nome'],"°")) AND (stristr($dados['nome'],"/")) AND (stristr($dados['nome'],"?"))
         AND (stristr($dados['nome'],";")) AND (stristr($dados['nome'],":")) AND (stristr($dados['nome'],".")) AND (stristr($dados['nome'],">")) AND (stristr($dados['nome'],","))
          AND (stristr($dados['nome'],"<")) AND (stristr($dados['nome'],"|")) AND (stristr($dados['nome'],"~")) AND (stristr($dados['nome'],"^")) AND (stristr($dados['nome'],"´"))
           AND (stristr($dados['nome'],"`")) AND (stristr($dados['nome'],"1")) AND (stristr($dados['nome'],"2")) AND (stristr($dados['nome'],"3")) AND (stristr($dados['nome'],"4"))
            AND (stristr($dados['nome'],"5")) AND (stristr($dados['nome'],"6")) AND (stristr($dados['nome'],"7")) AND (stristr($dados['nome'],"8")) AND (stristr($dados['nome'],"9"))
             AND (stristr($dados['nome'],"0"))){
      $erro = true;    }
    else if(stristr($dados['senha'],"'")){
      $erro = true;
    }
    else if(stristr($dados['email'],"'")){
      $erro = true;
    }
    else if(!stristr($dados['email'],"@")){
      $erro = true;
    }
    else if((!stristr($dados['email'],".com")) AND (!stristr($dados['email'],".net")) AND (!stristr($dados['email'],".gov"))){
      $erro = true;
    }
    
    else{
      $result_usuario = "SELECT id FROM usuario WHERE email='".  $dados["email"]  ."'";
      $resultado_usuario = mysqli_query($mysqli,$result_usuario);
      if(($resultado_usuario) AND ($resultado_usuario->num_rows != 0)){
          $erro = true;
        }
      }
    //var_dump($dados);
    
  if(!$erro){
    $dados['senha'] = password_hash($dados['senha'],PASSWORD_DEFAULT);
    $nome = $_POST["nome"];
  $senha = $_POST["senha"];
  $email = $_POST["email"];
  $sql = "INSERT INTO usuario (nome, senha, email) VALUES ('$nome', '$senha', '$email')";

  if (mysqli_query($mysqli, $sql)) {
      header("location: login.php");
    } else {
      echo "Error: " . $sql . "<br>";
    }
    
    mysqli_close($mysqli);
  }
 
  }
  
  ?></p>
<!DOCTYPE html>
<html lang="pt-br">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sub BuS</title>
  <link rel="stylesheet" href="imagem.css">
  <script scr="https://kit.fontawessome.com/a076d05399.js"></script>

  <link href="Imagem.css">
  <!-- CSS only -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link href="Style.css" rel="stylesheet"/>

  <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
  </script>
 

</head>

<body>




  <nav class="navbar navbar-expand-lg bg-light" style="margin-top: -0.8%;">
    <div class="container-fluid">
      <li style="list-style-type: none;"><a class="navbar-brand" href="index.php" style="color: rgb(233, 0, 0); font-size: 32; margin-right: -23%;">SBS</a></li>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <p class="titulo" style="margin-left: -53%; text-decoration: none;font-size: 20px;position:absolute;">Cadastrar</p>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">

          
          
          <li class="nav-item" style = "list-style-type: none;">
            
          </li>
        </ul>
        <form class="d-flex" role="search">
         
        </form>

        
        <button class="botao-login" type="submit" style="margin-right: 1%;" id="login"><a href="login.php" style="color: white; text-decoration: none;"><b>Entrar</b></a></button      </div>
    </div>
  </nav>
   
<b>
            <div class="dropdown">
          
              <div class = "dropbtn" style="border:none"type = "submit">Menu
                <scan id = "triangle-right">
          
                </scan>
              </div>
              
              
              <ul class="dropdown-content">
                <center>
                <li id="menu-linhas" class = "item-menu" style="color: white;list-style-type: none"><a href="linha.php" class = letra-menu id = "letra-nao-mudar">Linhas</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-rotas" class = "item-menu" style="color: white;list-style-type: none;"><a href="rotas.html" class = letra-menu id = "letra-nao-mudar">Rotas</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-terminais" class = "item-menu" style="color: white;list-style-type: none;"><a href="terminais.php" class = letra-menu id = "letra-nao-mudar">Terminais</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-ajuda" class = "item-menu" style="color: white;list-style-type: none;"><a href = "ajuda.html" class = letra-menu id = "letra-nao-mudar">Ajuda</a></li>
                </center>
              </ul>
            </div>
          </b> 



  <center>
      <div style="position: absolute;margin-left: 11.9%;"><img src="imagens/TCC_Logo.png" height="450px" width="450px "/>
      <div style="color: darkred;font-size: 30px;">
        SuB BuS
        <p style="font-size: 20px;">Sistema de rotas urbanas</p>
      </div>
      </div>
  <div style="width: 6px; height: 700px;background-color: black; border-radius: 6px;position: static;"></div>
 
  
<form method="POST" action="">
  <scan class="div-login"><p style="color: white; margin-top:5%;font-size: 30px;" action="cadastro.php" method="POST">Cadastrar</p>
  <div style="height: 5%;width:100%;position:absolute;"><p style="color:white;margin-bottom:-5%;margin_left:3%;"><?php
  
  
  
  $btnCadUsuario = filter_input(INPUT_POST,'btnCadUsuario',FILTER_SANITIZE_STRING);
  if($btnCadUsuario){
    include_once('cadastro_conexao.php');
    $dados_rc = filter_input_array(INPUT_POST,FILTER_DEFAULT);
  
    $erro = false;
  
    $dados_st = array_map('strip_tags',$dados_rc);
    $dados = array_map('trim',$dados_st);
    
    if(in_array('',$dados)){
      $erro = true;
      echo "Necessário preencher todos os campos";
    }
    else if((strlen($dados['senha']))<8){
      $erro = true;
      echo "A senha deve ter no mínimo 8 caracteres";
    }
    else if(stristr($dados['nome'],"'")){
      $erro = true;
      echo "Nao é possivel incluir o caracter (') no cadastro";
    }
    else if(stristr($dados['senha'],"'")){
      $erro = true;
      echo "Nao é possivel incluir o caracter (') no cadastro";
    }
    else if(stristr($dados['email'],"'")){
      $erro = true;
      echo "Nao é possivel incluir o caracter (') no cadastro";
    }
    else if(!stristr($dados['email'],"@")){
      $erro = true;
      echo "Informe um e-mail válido";
    }
    else if((!stristr($dados['email'],".com")) AND (!stristr($dados['email'],".net")) AND (!stristr($dados['email'],".gov"))){
      $erro = true;
      echo "Informe um e-mail válido";
    }
    else{
      $result_usuario = "SELECT id FROM usuario WHERE email='".  $dados['email']  ."'";
      if(($resultado_usuario) AND ($resultado_usuario->num_rows != 0)){
          $erro = true;
          echo "Este e-mail ja está cadastrado";
        }
      }
    //var_dump($dados);
    
  
 
  }
  
  ?></p></div>
  <li class="letra-cadastro-nome"><p>Nome:</p></li>
    <li style="list-style-type: none;color:  white;margin-left: 0.6%;"><input class="campo-texto-pequeno-cadastro" placeholder="Digite aqui" aria-label="Search" name="nome"></li>
    <li class="letra-cadastro"><p>E-mail:</p></li>
    <li style="list-style-type: none;color:  white;"><input class="campo-texto-pequeno-cadastro" placeholder="Digite aqui" aria-label="Search" name="email"></li>
    <li class="letra-cadastro"><p>Senha:</p></li>
    <li style="list-style-type: none;color:  white;"><input class="campo-texto-pequeno-cadastro" type="password" placeholder="Digite aqui" aria-label="Search" name="senha"></li>
    <li class="letra-cadastro"><p>Confirmar senha:</p></li>
    <li style="list-style-type: none;color:  white;margin-left: 0%;"><input class="campo-texto-pequeno-cadastro" type="password" placeholder="Digite aqui" aria-label="Search"></li>
  <!--<button class="botao-login-entrar" type="submit" style="margin-right: 1%;margin-top: 8%;width: 100px;" id="login-entrar"><a href="login.php" style="color: rgb(255, 255, 255); text-decoration: none;"><b>Cadastrar</b></a></button>-->
 <input class="botao-login-entrar" type="submit" name="btnCadUsuario" style="color: white; font-weight:bold;margin-top: 5%;" href="login.php">
  <li style="list-style-type: none;margin-top: 5%;"><a href="#" style="color: white;">Termos de uso</a></li>
</scan>
 </form>
 

 <footer>
      <div class="rodape">
        <li style="list-style-type: none;">

          <a style="color:white ; text-align: start;position: absolute; margin-left: -46%;" href="sobre.html">Sobre
            nós</a>
        <li style="list-style-type: none; margin-top: 0%;"><a
            style="color:white ; text-align: start;position: absolute; margin-left: -46%;" href="sobre.html">Sobre
            nós</a></li>

        <p style="color: white; font-size: 16 ;">
          SuB Bus é um projeto criado com o foco na atividade informativa e com intuito de facilitar o acesso ao
          transporte público de Londrina
          <br>
          2022
        </p>
        </li>
        <a style="color:white ; text-align: start;position: absolute; margin-left: -46%;margin-top: -2%;"
          href="equipe.html">Equipe de desenvolvedores</a>

      </div>

    </footer>
</center>
</body>

  


</html>