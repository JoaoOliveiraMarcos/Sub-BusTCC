function googleMudarPagina(){
    window.location.href = "index_usuario.php"
}

let regex =/(?=")[^.]+/gim;
var nome  = localStorage.getItem("nome")
var nome = nome.replaceAll("a","b")