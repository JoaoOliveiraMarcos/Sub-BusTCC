<?php

$server = 'localhost';
$bd = 'subbus';
$user = 'root';
$pass = 'senai';

$mysqli = new mysqli($server, $user, $pass, $bd);

if($mysqli->error){
    die("Falha na execução com o banco de dados: ".$mysqli->error);
}

/*
try{
    $connection = new PDO("pgsql: host=$server;port=5432;dbname=$bd", $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    echo "conectado ao banco de dados!";
}catch (PDOExceptio $e){
    echo "Falha ao conectar ao banco de dados. <br/>";
    die($e->getMessage());
}
*/




  
    
?>