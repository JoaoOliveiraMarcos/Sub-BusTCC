<?php

include('cadastro_conexao.php');

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sub BuS</title>
  <link rel="stylesheet" href="imagem.css">
  <script scr="https://kit.fontawessome.com/a076d05399.js"></script>

   <!-- Bootstrap CSS -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

  <link href="Imagem.css">
  <!-- CSS only -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link href="Style.css" rel="stylesheet"/>

  <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
  </script>
 

</head>

<body>




  <nav class="navbar navbar-expand-lg bg-light" style="margin-bottom: 0%;">
    <div class="container-fluid">
      <li style="list-style-type: none;"><a class="navbar-brand" href="index.php" style="color: rgb(233, 0, 0); font-size: 20; margin-right: -23%;">SBS</a></li>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <p class="titulo" style="margin-left: -53%; text-decoration: none;font-size: 20px;position:absolute;">Linhas</p>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">

          
          
          <li class="nav-item" style = "list-style-type: none;">
            
          </li>
        </ul>
        <form class="d-flex" role="search">
         
        </form>

        <button class="botao-login" type="submit" style="margin-right: 1%;" id="login"><a href="login.php" style="color: white; text-decoration: none;"><b>Entrar</b></a></button>
          <button class="botao-cadastro" type="submit" style="margin-right: 0%;" id="cadastro"><a href="cadastro.php" style="color: white;text-decoration: none;"><b>Cadastrar-se</b></a></button>
      </div>
    </div>
  </nav>
   
<b>
            <div class="dropdown">
          
              <div class = "dropbtn" style="border:none"type = "submit">Menu
                <scan id = "triangle-right">
          
                </scan>
              </div>
              
              
              <ul class="dropdown-content">
                <!--<li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="linha.html">Linhas</a></li>
          
                <li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="rotas.html">Rotas</a></li>
          
                <li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="terminais.html">Terminais<br></a></li>
          
                <li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="ajuda.html">Ajuda</a></li>-->
                <center>
                <li id="menu-linhas" class = "item-menu" style="color: white;list-style-type: none"><a href="linha.php" class = letra-menu id = "letra-nao-mudar">Linhas</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-rotas" class = "item-menu" style="color: white;list-style-type: none;"><a href="rotas.html" class = letra-menu id = "letra-nao-mudar">Rotas</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-terminais" class = "item-menu" style="color: white;list-style-type: none;"><a href="terminais.php" class = letra-menu id = "letra-nao-mudar">Terminais</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-ajuda" class = "item-menu" style="color: white;list-style-type: none;"><a href = "ajuda.html" class = letra-menu id = "letra-nao-mudar">Ajuda</a></li>
                </center>
              </ul>
            </div>
          </b> 

          <center>
          <b><li class = "li-linha">Pesquise suas linhas de ônibus aqui:</li></b>
            <form method="POST" id="form-pesquisa" action="">
              <b><li style="list-style-type: none;margin-left:3.6%" class="tamanho-fonte">Linhas:<input id="pesquisa"name="busca" type="text" class="pesquisar-linha" placeholder="Digite o número das linhas, ex: 201, 800..." aria-label="Search" style="margin-top: 2%;">
              <button class="botao-pesquisar" type="submit" id="botao-pesquisar" style="margin-left: 1%;"><a style="color: white;text-decoration: none;"><b>Pesquisar</b></a></button></li></b> <li class = "li-linha-estilo">
              
            </form>
            <!--<script type="javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>-->
            <script src="./Animacao.js"></script>

            <br>

          <div>
            <table class="table table-bordered border-less" width="75%">
               <thead >
                  <tr>
                      <th>Linhas</th>
                      <th></th>
                      <th>Horario inicio</th>
                      <th>Horario Término</th>
                      <th>Horario Especial</th>
                      <th>Lotação</th>
                      <th>Dias de funcionamento</th>
                  </tr>
               </thead>
               <tbody>
                    <?php
                    if(!isset($_POST['busca'])){
                      ?>
                      <tr>
                          <td>Digite algo para pesquisar</td>
                      </tr>
                    <?php
                    } else {
                      $pesquisa = $mysqli -> real_escape_string($_POST['busca']);
                      $sql_code = "SELECT * FROM onibus 
                      WHERE linhas LIKE '%$pesquisa%'
                      OR rotas LIKE '%$pesquisa%' 
                      OR dias_funcionamento LIKE '%$pesquisa%'
                      ORDER BY id ASC";

                      $sql_query = $mysqli->query($sql_code) or die ("ERRO ao consultar" . $mysqli->error);

                      if($sql_query ->num_rows == 0){
                        ?>
                       <tr>
                          <td colpsan="7">Nenhum resultado encontrado</td>
                       </tr>
                       <?php
                      } else{
                        while($dado = $sql_query ->fetch_assoc() ){
                          ?>
                          <tr>
                              <th><?php echo $dado ['linhas']; ?></th>
                              <td><?php echo $dado ['rotas']; ?></td>
                              <td><?php echo $dado ['horario_inicio']; ?></td>
                              <td><?php echo $dado ['horario_termino']; ?></td>
                              <td><?php echo $dado ['horario_especial']; ?></td>
                              <td><?php echo $dado ['media_lotacao']; ?></td>
                              <td><?php echo $dado ['dias_funcionamento']; ?></td>
                          </tr>
                          <?php
                        }

                      }
                          ?>
                    <?php
                    } ?>
                  </tbody>
            </table>
          </div>
            

              
  <center>
  <form style="height: 600px; width: 400px;"></form>
  <footer>
    <div class="rodape">
  <li style="list-style-type: none;">
      
    <a style="color:white ; text-align: start;position: absolute; margin-left: -46%;" href="sobre.html">Sobre nós</a>
    <li style="list-style-type: none; margin-top: 0%;"><a style="color:white ; text-align: start;position: absolute; margin-left: -46%;" href="sobre.html">Sobre nós</a></li>
  
      <p style="color: white; font-size: 10;">
        SuB Bus é um projeto criado com o foco na atividade informativa e com intuito de facilitar o acesso ao
        transporte público de Londrina
        <br>
        2022
      </p>
    </li>
    <a style="color:white ; text-align: start;position: absolute; margin-left: -46%;margin-top: -2%;" href="equipe.html">Equipe de desenvolvedores</a>
      
    </div>
  
  </footer>
</center>
</body>

  


</html>